Open examples/index.html to view the demos.

Open tests/TestRunner.html to run the unit tests (uses Selenium, requires
Firefox or IE)

the source directory contains the source for the ToolMan DHTML Library.
Some examples (like edit-in-place) have their source code in their
HTML file in the examples directory.
